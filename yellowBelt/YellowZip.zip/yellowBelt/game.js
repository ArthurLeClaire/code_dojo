function firstFunction()
{
    document.img("stonePunk").click();
}

var increaseCart = 0
function functionIncrease2() {

    increaseCart++
    document.querySelector(".cartItems").innerText = increaseCart 
}

var increaseCart = 0
function functionIncrease1() {

    increaseCart++
    document.querySelector(".cartItems").innerText = increaseCart 
}

var increaseCart = 0
function functionIncrease() {

    increaseCart++
    document.querySelector(".cartItems").innerText = increaseCart 
}

// var toggle = false
// function changePic() {

//     imgsrc = document.getElementById("stonePunk").src;
//     if (imgsrc.indexOf(images\stonepunk.png) != 1) {
//         document.getElementById("stonePunk").src = "cafe-neko.png"
//     }
//     else {
//         document.getElementById("stonePunk").src = "images\stonepunk.png"
//     }
// }


    // if (toggle === true) {
    //     document.getElementById('punkStone').src = 'images\cafe-neko.png';
    // } else {
    //     document.getElementById('punkStone').src = 'images\stonepunk.png';
    // }
    
    // toggle = !toggle;
// }
